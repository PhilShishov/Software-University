﻿namespace MusicHub.Data.Models
{
    public enum Genre
    {
        Blues, Rap, PopMusic, Rock, Jazz
    }
}
