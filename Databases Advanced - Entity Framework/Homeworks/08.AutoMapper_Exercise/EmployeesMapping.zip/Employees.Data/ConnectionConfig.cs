﻿
namespace Employees.Data
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class ConnectionConfig
    {
        public const string ConnectionString =
            "Server=.\\SQLEXPRESS;Database=EmployeesDb;Integrated Security=True;";
    }
}
