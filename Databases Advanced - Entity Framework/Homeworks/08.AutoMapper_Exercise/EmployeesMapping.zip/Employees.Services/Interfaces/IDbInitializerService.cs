﻿namespace Employees.Services.Interfaces
{
    public interface IDbInitializerService
    {
        void InitializeDatabase();
    }
}