﻿namespace FastFood.Web.ViewModels.Items
{
    public class CreateItemViewModel
    {
        public string CategoryName { get; set; }
    }
}
