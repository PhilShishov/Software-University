﻿
namespace P01_StudentSystem.Data
{
    public static class Config
    {
        public const string ConnectionString = 
            "Server=.\\SQLEXPRESS;Database=StudentSystem;Integrated Security=True;";
    }
}
