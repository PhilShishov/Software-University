﻿
namespace P03_FootballBetting.Data
{
    public static class Config
    {
        public const string ConnectionString =
            "Server=.\\SQLEXPRESS;Database=FootballBetting;Integrated Security=True;";
    }
}
