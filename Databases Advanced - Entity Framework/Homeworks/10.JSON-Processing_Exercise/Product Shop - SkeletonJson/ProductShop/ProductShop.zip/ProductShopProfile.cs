﻿
namespace ProductShop
{
    using AutoMapper;
    using ProductShop.DTOs.Export;
    using ProductShop.Models;

    public class ProductShopProfile : Profile
    {
        public ProductShopProfile()
        {
        }
    }
}
