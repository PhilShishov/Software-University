﻿namespace P03_SalesDatabase.Data
{
    public class Config
    {
        public const string ConnectionString = "Server=.\\SQLEXPRESS;Database=Sales;Integrated Security=True;";
    }
}
