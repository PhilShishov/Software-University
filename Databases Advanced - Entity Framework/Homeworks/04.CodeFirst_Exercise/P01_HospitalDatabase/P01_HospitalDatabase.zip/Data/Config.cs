﻿
namespace P01_HospitalDatabase.Data
{
    public class Config
    {
        public const string ConnectionString = "Server=.\\SQLEXPRESS;Database=Hospital;Integrated Security=True;";
    }
}
