﻿namespace PlayersAndMonsters
{
    using Core;
    using Core.Contracts;
    using Core.Factories;
    using Core.Factories.Contracts;
    using Repositories;
    using Repositories.Contracts;
    using IO;
    using IO.Contracts;
    using Models.BattleFields;
    using Models.BattleFields.Contracts;
    using System;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            ManagerController managerController = new ManagerController();

            string line = Console.ReadLine();

            while (line != "Exit")
            {
                string[] commandItems = line.Split();
                string result = string.Empty;

                try
                {
                    switch (commandItems[0])
                    {
                        case "AddPlayer":
                            result += managerController.AddPlayer(commandItems[1],
                                commandItems[2]);
                            break;

                        case "AddCard":
                            result += managerController.AddCard(commandItems[1],
                                commandItems[2]);
                            break;

                        case "AddPlayerCard":
                            result += managerController.AddPlayerCard(commandItems[1],
                                commandItems[2]);
                            break;

                        case "Fight":
                            result += managerController.Fight(commandItems[1],
                                commandItems[2]);
                            break;

                        case "Report":
                            result += managerController.Report();
                            break;

                        default:
                            break;
                    }

                    Console.WriteLine(result);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

                line = Console.ReadLine();
            }
        }

    }
}
