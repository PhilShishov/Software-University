﻿
[Author("Philip")]
public class StartUp
{
    [Author("Ivan")]
    private static void Main()
    {
    }
}
