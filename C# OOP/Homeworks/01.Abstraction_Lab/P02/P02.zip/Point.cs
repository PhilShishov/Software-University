﻿namespace P02
{
    public class Point
    {
        public Point(int x, int y)
        {
            this.CoordinateX = x;
            this.CoordinateY = y;
        }

        public int CoordinateX { get; set; }

        public int CoordinateY { get; set; }

    }
}
