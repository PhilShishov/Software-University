﻿namespace P04
{
    public enum DiscountType
    {
        None,
        SecondVisit = 10,
        VIP = 20
    }
}
