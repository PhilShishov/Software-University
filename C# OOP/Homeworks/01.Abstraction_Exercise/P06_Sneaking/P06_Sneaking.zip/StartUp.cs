﻿namespace P06_Sneaking
{
    public class StartUp
    {        
        public static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
