﻿namespace FoodShortage.Contracts
{
    public interface IRebel
    {
        string Group { get; }
    }
}
