const homeController = function () {
    const getHome = async function (context) {
        // helper.addHeaderInfo(context);
        const loggedIn = storage.getData('userInfo') !== null;

        if (loggedIn) {
            const username = JSON.parse(storage.getData('userInfo')).username;
            context.loggedIn = loggedIn;
            context.username = username;
            try {
                let response = await postModel.getAllPosts();
                context.posts = await response.json();
                // context.isCreator = JSON.parse(storage.getData('userInfo')).username === context.posts.creator;

            } catch (error) {
                console.log(error);
            }
        }

        context.loadPartials({
            header: './views/common/header.hbs',
            postView: './views/post/postView.hbs',
        }).then(function () {
            this.partial('./views/home/homePage.hbs')
        })
    };

    return {
        getHome
    }
}();