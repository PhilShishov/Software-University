﻿namespace LoggerApplication.Models.Contracts
{
    public interface ILayout
    {
        string Format { get; }
    }
}