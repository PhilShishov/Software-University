﻿namespace WildFarm.Exceptions
{
    public static class ExceptionMessages
    {
        public static string InvalidFoodTypeException = "{0} does not eat {1}!";
    }
}
