﻿namespace P02_CarsSalesman
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Runner runner = new Runner();
            runner.Start();
        }
    }
}
