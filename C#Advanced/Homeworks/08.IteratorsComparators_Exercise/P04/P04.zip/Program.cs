﻿using System;
using System.Linq;

namespace P04
{
    class Program
    {
        static void Main(string[] args)
        {
            var input = Console.ReadLine()
                .Split(", ")
                .Select(int.Parse)
                .ToArray();

            Lake lake = new Lake(input);

            Console.WriteLine(string.Join(", ", lake));

            //var evenPositions = input
            //    .Where(i => i % 2 == 0)
            //    .ToList();

            //var oddPositions = input
            //    .Where(i => i % 2 != 0)
            //    .ToList();


        }
    }
}
