﻿namespace P05
{
    using System;
    using System.Collections.Generic;
    using System.Text;


    public class DateModifier
    {
        public double CalculateDayDifference(string dateOne, string dateTwo)
        {
            DateTime datetimeOne = DateTime.Parse(dateOne);
            DateTime datetimeTwo = DateTime.Parse(dateTwo);

            double dateDiff = Math.Abs((datetimeOne - datetimeTwo).TotalDays);

            return dateDiff;
        }
    }
}
