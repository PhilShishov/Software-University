﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GenericCountMethod
{
    class Program
    {
        static void Main(string[] args)
        {
            int lines = int.Parse(Console.ReadLine());

            Box<double> box = new Box<double>();

            for (int i = 0; i < lines; i++)
            {
                var input = double.Parse(Console.ReadLine());
                box.Add(input);
            }

            var elementToCompare = double.Parse(Console.ReadLine());

            Console.WriteLine(Compare(box.Data, elementToCompare));
        }

        private static int Compare<T>(List<T> data, double element)
        {
            int count = 0;

            foreach (var item in data)
            {
                if (element.CompareTo(item) < 0)
                {
                    count++;
                }
            }
            return count;
        }
    }
}
