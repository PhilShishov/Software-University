function getData () {
	
	//TODO...
}