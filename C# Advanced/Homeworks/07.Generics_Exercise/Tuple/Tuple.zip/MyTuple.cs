﻿namespace Tuple
{
    using System;
    using System.Collections.Generic;
    using System.Text;


    public class MyTuple<T, V>
    {
        public MyTuple(T item1, V item2)
        {
            this.Item1 = item1;
            this.Item2 = item2;
        }

        public T Item1 { get; private set; }
        public V Item2 { get; private set; }

        public override string ToString()
        {
            return $"{this.Item1} -> {this.Item2}";
        }
    }
}
