﻿using System;
using System.Collections.Generic;

namespace P06
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            var cars = new List<Car>();

            for (int i = 0; i < n; i++)
            {
                string[] tokens = Console.ReadLine().Split();

                Car car = new Car(tokens[0], double.Parse(tokens[1]), double.Parse(tokens[2]));

                if (!cars.Contains(car))
                {
                    cars.Add(car);
                }
            }

            string input = Console.ReadLine();

            while (input != "End")
            {
                string[] tokens = input.Split();

                string model = tokens[1];
                double distance = double.Parse(tokens[2]);
                int indexOfCurrentCar = cars.IndexOf(cars.Find(x => x.Model == model));
                cars[indexOfCurrentCar].Drive(distance);

                input = Console.ReadLine();
            }

            foreach (var vehicle in cars)
            {
                Console.WriteLine($"{vehicle.Model} {vehicle.FuelAmount:F2} {vehicle.TravelledDistance}");
            }
        }
    }
}
