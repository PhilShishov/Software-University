﻿namespace Andreys.Models
{
    public enum Gender
    {
        Male = 1,
        Female = 2
    }
}


