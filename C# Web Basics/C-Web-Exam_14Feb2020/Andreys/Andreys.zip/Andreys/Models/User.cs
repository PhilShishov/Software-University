namespace Andreys.Models
{
    using SIS.MvcFramework;

    public class User : IdentityUser<string>
    {
    }
}