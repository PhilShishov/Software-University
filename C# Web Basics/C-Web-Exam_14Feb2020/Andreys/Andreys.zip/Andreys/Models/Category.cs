﻿namespace Andreys.Models
{
    public enum Category
    {
        Shirt = 1,
        Denim = 2,
        Shorts = 3,
        Jacket = 4
    }
}


